import copy
import tkinter
from os.path import abspath
from tkinter import Frame, CENTER, Button, Canvas, NW
from tkinter.ttk import Treeview

from PIL import Image, ImageTk
from pkg_resources import resource_filename

from Extensions.Interface import IExtensionApp
from src.Common.loadedcomicinfo import LoadedComicInfo, CoverActions
from src.MetadataManager.GUI.CoverWidget import CoverFrame, CanvasCoverWidget
from src.MetadataManager.GUI.widgets import ScrolledFrameWidget

action_template = abspath(resource_filename(__name__, '../../res/cover_action_template.png'))

def on_button_click(mode, loaded_cinfo: LoadedComicInfo, front_or_back):
    print("Clicked button.")
    print(f"Is: {front_or_back}")
    print(f"Path: {loaded_cinfo.file_path}")


class ComicFrame(CoverFrame):
    def __init__(self, master, loaded_cinfo:LoadedComicInfo):
        # frame = Frame(self)
        super(CoverFrame, self).__init__(master, highlightbackground="black", highlightthickness=2)
        # frame.pack()
        self.loaded_cinfo: LoadedComicInfo = loaded_cinfo
        self.configure(highlightthickness=1, highlightcolor="grey", highlightbackground="grey")

        overlay_image = Image.open(action_template)
        overlay_image = overlay_image.resize((190, 260), Image.ANTIALIAS)



        # COVER
        self.cover_frame = Frame(self)
        self.cover_frame.pack(side="left")

        self.cover_canvas = CanvasCoverWidget(self.cover_frame)
        self.cover_canvas.configure(background='#878787', height='260', width='190')
        self.cover_canvas.pack(side="top", expand=False, anchor=CENTER)

        self.cover_canvas.overlay_image = ImageTk.PhotoImage(overlay_image, master=self.cover_canvas)
        self.cover_canvas.overlay_id = self.cover_canvas.create_image(150, 150, image=self.cover_canvas.overlay_image,
                                                                      state="hidden")
        self.cover_canvas.action_id = self.cover_canvas.create_text(150, 285, text="", justify="center", fill="yellow",
                                                                    font=('Helvetica 15 bold'))
        self.cover_canvas.no_image_warning_id = self.cover_canvas.create_text(150, 120,
                                                                              text="No Cover!\nNo image\ncould be\nloaded",
                                                                              justify="center", fill="red",
                                                                              state="hidden",
                                                                              font=('Helvetica 28 bold'))
        self.cover_canvas.image_id = self.cover_canvas.create_image(0, 0, anchor=NW)
        self.cover_canvas.scale("all", -1, 1, 0.63, 0.87)
        self.cover_canvas.tag_lower(self.cover_canvas.image_id)
        btn_frame = Frame(self.cover_frame)
        btn_frame.pack(side="bottom", anchor=CENTER, fill="x")
        btn = Button(btn_frame, text="✎", command=lambda:
        self.cover_action(self.loaded_cinfo, action=CoverActions.REPLACE))
        btn.pack(side="left", fill="x", expand=True)
        self.action_buttons.append(btn)

        btn = Button(btn_frame, text="🗑", command=lambda:
        self.cover_action(self.loaded_cinfo, action=CoverActions.DELETE))
        btn.pack(side="left", fill="x", expand=True)
        self.action_buttons.append(btn)

        btn = Button(btn_frame, text="➕", command=lambda:
        self.cover_action(self.loaded_cinfo, action=CoverActions.APPEND))
        btn.pack(side="left", fill="x", expand=True)
        self.action_buttons.append(btn)

        btn = Button(btn_frame, text="Reset", command=lambda:
        self.cover_action(self.loaded_cinfo, action=CoverActions.RESET))
        btn.pack(side="left", fill="x", expand=True)
        self.action_buttons.append(btn)

        # Load cover
        self.cover_action(self.loaded_cinfo,auto_trigger=True)



        # create the second canvas
        frame = self.backcover_canvas = Frame(self, background="grey", highlightcolor="grey", highlightthickness=6)
        frame.pack(side="right")
        canvas2 = self.canvas2 = Canvas(frame)
        canvas2.configure(height='260', width='190')
        canvas2.pack(side="top", expand=False, anchor=CENTER)
        # print the image in the second canvas
        canvas2.create_image(0, 0, image=loaded_cinfo.backcover_cache, anchor="nw")
        # self.display_canvas_button_action_bar(frame, loaded_cinfo, "back")

        # bind the click event to the on_clicked_canvas method

    # def display_canvas_button_action_bar(self, frame, loaded_cinfo, front_or_back):
    #     if front_or_back not in ("front", "back"):
    #         return
    #     frame_buttons = self.frame_buttons = Frame(frame)
    #     frame_buttons.pack(side="bottom", anchor=CENTER, fill="x")
    #     Button(frame_buttons, text="✎",
    #            command=lambda item=loaded_cinfo, fb=front_or_back:
    #            on_button_click("edit", loaded_cinfo=item, front_or_back=fb)).pack(side="left", fill="x",
    #                                                                                    expand=True)
    #     Button(frame_buttons, text="🗑",
    #            command=lambda item=loaded_cinfo, fb=front_or_back:
    #            on_button_click("delete", loaded_cinfo=item, front_or_back=fb)).pack(side="left", fill="x",
    #                                                                                      expand=True)
    #     Button(frame_buttons, text="➕",
    #            command=lambda item=loaded_cinfo, fb=front_or_back:
    #            on_button_click("append", loaded_cinfo=item, front_or_back=fb)).pack(side="left", fill="x",
    #                                                                                      expand=True)
class CoverManager(IExtensionApp):
    name = "CoverManager"

    scrolled_widget: Frame
    top_level: tkinter.Toplevel = tkinter.Toplevel

    def redraw(self, event):
        """
        Redraws the widgets in the scrolled widget based on the current size of the window.

        The function is triggered by an event (e.g. window resize) and only redraws the widgets if
        the window dimensions have changed since the last redraw. The widgets are laid out in a grid
        with a number of columns equal to the number of widgets that fit in the current width of the
        window, minus 300 pixels.

        :param: event: The event that triggered to redraw (e.g. a window resize event).

        """
        width = self.winfo_width()
        height = self.winfo_height()
        if not event:
            return
        if not (width != event.width or height != event.height):
            return

        width = self.winfo_width() - 300
        if width == self.prev_width:
            return
        childrens = self.scrolled_widget.winfo_children()
        for child in childrens:
            child.grid_forget()
        if not self.scrolled_widget.winfo_children():
            return

        num_widgets = width // 414
        #
        # redraw the widgets
        widgets_to_redraw = copy.copy(self.scrolled_widget.winfo_children())  # self.scrolled_widget.grid_slaves()
        i = 0
        j = 0
        while widgets_to_redraw:
            if j >= num_widgets:
                i += 1
                j = 0
            widgets_to_redraw.pop().grid(row=i, column=j)
            j += 1

    def serve_gui(self):
        """
        This function creates and serves the GUI for the application.
        """
        # # super().__init__(master=cls.master_frame)
        # top_frame = ScrolledFrameWidget(self.master_frame).create_frame()
        # # frame.title("Cover Manager")
        #
        side_panel_control = Frame(self.master_frame)
        side_panel_control.pack(side="right", expand=False, fill="y")
        #
        ctr_btn = Frame(self.master_frame)
        ctr_btn.pack()
        #
        #
        tree = self.tree = Treeview(side_panel_control, columns=("Filename", "type"), show="headings", height=8)
        tree.column("#1")
        tree.heading("#1", text="Filename")
        tree.column("#2", anchor=CENTER, width=80)
        tree.heading("#2", text="Type")
        tree.pack(expand=True, fill="y", pady=80, padx=30)

        frame = ScrolledFrameWidget(self.master_frame)
        frame.pack(fill="both", expand=True)
        self.scrolled_widget = frame.create_frame()
        # scrolled_widget.pack(expand=False,fill="both")

        # iterate over the LoadedComicInfo objects in loaded_cinfo_list

        self.tree_dict = {}
        self.prev_width = 0
        self.last_folder = ""
        self.selected_frames = []
        # comic_frame.pack()
        # bind the redraw function to the <Configure> event
        # so that it will be called whenever the window is resized
        self.bind("<Configure>", self.redraw)

        self.redraw(None)
        for i, cinfo in enumerate(self._super.loaded_cinfo_list):
            # create a ComicFrame for each LoadedComicInfo object
            comic_frame = ComicFrame(self.scrolled_widget, cinfo)

            comic_frame.cover_canvas.bind("<Button-1>",
                                     lambda event, frame_=comic_frame: self.select_frame(event, frame_, "front"))
            comic_frame.backcover_canvas.bind("<Button-1>",
                                     lambda event, frame_=comic_frame: self.select_frame(event, frame_, "back"))
            comic_frame.grid()
        self.redraw(None)
    def select_frame(self, event, frame: ComicFrame, pos):
        print(pos)
        if (frame, pos) in self.selected_frames:
            # self.tree.get_children()
            # self.tree.delete(selected_item)
            for children in self.tree.get_children():
                if self.tree_dict[children]["cinfo"] == frame.loaded_cinfo and self.tree_dict[children]["type"] == pos:
                    self.selected_frames.remove((frame, pos))
                    self.tree.delete(children)
                    del self.tree_dict[children]
            print("green" if frame in self.selected_frames else "gray")
            if pos == "front":

                frame.cover_canvas.configure(highlightbackground="#f0f0f0", highlightcolor="white")
            else:
                frame.backcover_canvas.configure(highlightbackground="#f0f0f0", highlightcolor="white")

            # frame.configure(highlightbackground="green", highlightcolor="green")
            # frame.frame_buttons.configure(background="green")
        else:
            node = self.tree.insert('', 'end', text="1", values=(frame.loaded_cinfo.file_name, pos))
            self.tree_dict[node] = {"cinfo": frame.loaded_cinfo, "type": pos}
            self.selected_frames.append((frame, pos))
            if pos == "front":
                frame.cover_canvas.configure(highlightbackground="green", highlightcolor="green")
            else:
                frame.backcover_canvas.configure(highlightbackground="green", highlightcolor="green")
